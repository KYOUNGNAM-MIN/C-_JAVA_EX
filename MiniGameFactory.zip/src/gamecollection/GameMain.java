package gamecollection;

abstract public class GameMain {
	protected String message;
	protected String playerName;
	public String[] allScore = new String[4];
	protected boolean gameState = true;
	public GameMain(){}
	public abstract void startScreen();
	public abstract void endScreen();
	public abstract void run();
	
	protected void slowPrint(String message, long millisPerChar) {
		for (int i = 0; i < message.length(); i++)
        {
            System.out.print(message.charAt(i));
            try
            {
                Thread.sleep(millisPerChar);
            }
            catch (InterruptedException e)
            {
                e.printStackTrace();
            }
        }
	}
}