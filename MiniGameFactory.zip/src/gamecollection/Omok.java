package gamecollection;
import java.util.Scanner;

public class Omok extends GameMain implements Panel{
	Scanner sc;
	private int turn = 0;
	private int userX, userY, aiX, aiY;
	private String[][] panel = new String[10][10];
	
	
	public Omok(String player) {
		message = "오목 게임을 실행합니다.\n";
		slowPrint(message, 40);
		gameState = true;
		sc = new Scanner(System.in);
		playerName = player;
	}
	@Override
	public void startScreen() {
		message = playerName + "님 안녕하세요. 오목 게임에 오신 것을 환영합니다.\n" + "오목 게임은 AI 가이드 민숭실과 대결하게 됩니다.\n" 
				+ "오목 게임의 룰은 앞서 설명한 대로 5개의 돌을 이어지도록 두면 승리입니다.\n" + "그럼 게임을 시작하겠습니다.\n";
		slowPrint(message,40);
	}
	@Override
	public void endScreen() {
		message = "오목 게임을 종료합니다.\n";
		slowPrint(message,40);
	}
	@Override
	public void makePanel() {
		for(int i=0; i<10; i++) {
			for(int j=0; j<10; j++) {
				panel[i][j] = " + ";
			}
		}
	}
	@Override
	public void showPanel() {
		for(int i=0; i<10; i++) {
			for(int j=0; j<10; j++) {
				System.out.print(panel[i][j]);
			}
			System.out.println();
		}
	}
	@Override
	// 돌이 5개 이어졌는 지 체크하는 함수
	public boolean checkPanel() {
		boolean check;
		//가로로 다섯개 이어져 있는 지 체크
		for(int i=0; i<10; i++) {
			for(int j=0; j<10; j++) {
				check = true;
				// 사용자꺼 체크
				if(panel[i][j].equals(" ● ")) {
					int tmpJ = j;
					for(int k=0; k<5; k++) {
						if(tmpJ == 10) {
							check = false;
							break;
						}
						if(!panel[i][tmpJ].equals(" ● ")) {
							check = false;
							break;
						}
						tmpJ++;
					}
					if(check) {
						message = "!!! " + playerName + " 님이 이겼습니다!!!\n" + "제가 봐드렸습니다~~ 하하! 다음 게임은 쉽지 않을겁니다^^\n";
						slowPrint(message,40);
						allScore[0] = "오목 게임의 승자: " + playerName;
						return false;
					}
				}
				// AI꺼 체크
				else if(panel[i][j].equals(" ○ ")) {
					int tmpJ = j;
					for(int k=0; k<5; k++) {
						if(tmpJ == 10) {
							check = false;
							break;
						}
						if(!panel[i][tmpJ].equals(" ○ ")) {
							check = false;
							break;
						}
						tmpJ++;
					}
					if(check) {
						message = "!!! AI 민숭실님이 이겼습니다!!!\n";
						slowPrint(message,40);
						allScore[0] = "오목 게임의 승자: AI 민숭실";
						return false;
					}
				}
			}
		}
		//세로로 다섯개 이어져 있는 지 체크
		for(int i=0; i<10; i++) {
			check = true;
			for(int j=0; j<10; j++) {
				// 사용자꺼 체크
				if(panel[i][j].equals(" ● ")) {
					int tmpI = i;
					for(int k=0; k<5; k++) {
						if(tmpI==10) {
							check = false;
							break;
						}
						if(!panel[tmpI][j].equals(" ● ")) {
							check = false;
							break;
						}
						tmpI++;
					}
					if(check) {
						message = "!!! " + playerName + " 님이 이겼습니다!!!\n" + "제가 봐드렸습니다~~ 하하! 다음 게임은 쉽지 않을겁니다^^\n";
						slowPrint(message,40);
						allScore[0] = "오목 게임의 승자: " + playerName;
						return false;
					}
				}
				// AI꺼 체크
				else if(panel[i][j].equals(" ○ ")) {
					int tmpI = i;
					for(int k=0; k<5; k++) {
						if(tmpI == 10) {
							check = false;
							break;
						}
						if(!panel[tmpI][j].equals(" ○ ")) {
							check = false;
							break;
						}
						tmpI++;
					}
					if(check) {
						message = "!!! AI 민숭실님이 이겼습니다!!!\n";
						slowPrint(message,40);
						allScore[0] = "오목 게임의 승자: AI 민숭실";
						return false;
					}
				}
			}
		}
		//좌측아래 대각선으로 다섯개 이어져 있는 지 체크
		for(int i=0; i<10; i++) {
			check = true;
			for(int j=0; j<10; j++) {
				// 사용자꺼 체크
				if(panel[i][j].equals(" ● ")) {
					int tmpI = i;
					int tmpJ = j;
					for(int k=0; k<5; k++) {
						if(tmpI==10 || tmpJ<0) {
							check = false;
							break;
						}
						if(!panel[tmpI][tmpJ].equals(" ● ")) {
							check = false;
							break;
						}
						tmpI++;
						tmpJ--;
					}
					if(check) {
						message = "!!! " + playerName + " 님이 이겼습니다!!!\n" + "제가 봐드렸습니다~~ 하하! 다음 게임은 쉽지 않을겁니다^^\n";
						slowPrint(message,40);
						allScore[0] = "오목 게임의 승자: " + playerName;
						return false;
					}
				}
				// AI꺼 체크
				else if(panel[i][j].equals(" ○ ")) {
					int tmpI = i;
					int tmpJ = j;
					for(int k=0; k<5; k++) {
						if(tmpI==10 || tmpJ<0) {
							check = false;
							break;
						}
						if(!panel[tmpI][tmpJ].equals(" ○ ")) {
							check = false;
							break;
						}
						tmpI++;
						tmpJ--;
					}
					if(check) {
						message = "!!! AI 민숭실님이 이겼습니다!!!\n";
						slowPrint(message,40);
						allScore[0] = "오목 게임의 승자: AI 민숭실";
						return false;
					}
				}
			}
		}
		//우측아래 대각선으로 다섯개 이어져 있는 지 체크
		for(int i=0; i<10; i++) {
			check = true;
			for(int j=0; j<10; j++) {
				// 사용자꺼 체크
				if(panel[i][j].equals(" ● ")) {
					int tmpI = i;
					int tmpJ = j;
					for(int k=0; k<5; k++) {
						if(tmpI==10 || tmpJ==10) {
							check = false;
							break;
						}
						if(!panel[tmpI][tmpJ].equals(" ● ")) {
							check = false;
							break;
						}
						tmpI++;
						tmpJ++;
					}
					if(check) {
						message = "!!! " + playerName + " 님이 이겼습니다!!!\n" + "제가 봐드렸습니다~~ 하하! 다음 게임은 쉽지 않을겁니다^^\n";
						slowPrint(message,40);
						allScore[0] = "오목 게임의 승자: " + playerName;
						return false;
					}
				}
				// AI꺼 체크
				else if(panel[i][j].equals(" ○ ")) {
					int tmpI = i;
					int tmpJ = j;
					for(int k=0; k<5; k++) {
						if(tmpI==10 || tmpJ==10) {
							check = false;
							break;
						}
						if(!panel[tmpI][tmpJ].equals(" ○ ")) {
							check = false;
							break;
						}
						tmpI++;
						tmpJ++;
					}
					if(check) {
						message = "!!! AI 민숭실님이 이겼습니다!!!\n";
						slowPrint(message,40);
						allScore[0] = "오목 게임의 승자: AI 민숭실";
						return false;
					}
				}
			}
		}
		return true;
	}
	@Override
	public void run() {
		System.out.println("<<<<<<<<<<  오     목    >>>>>>>>>>");
		makePanel();
		showPanel();
		message = "각 돌은 1~10 범위의 x와 y의 좌표를 가지고 있습니다.\n";
		slowPrint(message,40);
		
		//오목 두기
		while(gameState) {
			//사용자 turn == 0 
			if(turn == 0) {
				message = playerName + "님의 차례입니다.\n" + "돌을 두고 싶은 x의 좌표를 숫자로 입력해주세요 >> ";
				slowPrint(message,40);
				userX = sc.nextInt();
				message = "돌을 두고 싶은 y의 좌표를 숫자로 입력해주세요 >> ";
				slowPrint(message,40);
				userY = sc.nextInt();
				
				while(panel[userX-1][userY-1] .equals(" ○ ") || panel[userX-1][userY-1].equals(" ● ") || userX-1<0 
						|| userY-1<0 || userX-1>9 || userY-1>9) {
					message = "잘못된 입력입니다. 다시 입력해주세요.\n" + playerName + "님의 차례입니다.\n" + "돌을 두고 싶은 x의 좌표를 숫자로 입력해주세요 >> ";
					slowPrint(message,40);
					userX = sc.nextInt();
					message = "돌을 두고 싶은 y의 좌표를 숫자로 입력해주세요 >> ";
					slowPrint(message,40);
					userY = sc.nextInt();
				}
				panel[userX-1][userY-1] = " ● ";
				gameState = checkPanel();
			}
			//AI turn == 1
			else {
				message = "AI 가이드 민숭실의 차례입니다.\n";
				slowPrint(message,40);
				
				aiX = (userX-1) + (int)(Math.random()*3 + 1) - 2;
				aiY = (userY-1) + (int)(Math.random()*3 + 1) - 2;

				while(panel[aiX][aiY].equals(" ● ") || panel[aiX][aiY].equals(" ○ ") || aiX<0 || aiY<0 || aiX>9 || aiY>9) {
					aiX = (int)(Math.random()*10);
					aiY = (int)(Math.random()*10);
				}
				
				panel[aiX][aiY] = " ○ ";
				gameState = checkPanel();
			}
			
			//돌을 두고 난 후의 오목판 보여주기
			showPanel();
			turn = (turn == 0) ? 1 : 0;
		}
		endScreen();
	}
	
}
