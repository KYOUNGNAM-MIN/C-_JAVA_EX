package gamecollection;

import java.util.Random;
import java.util.Scanner;

public class Mine extends GameMain implements Panel{
	private static final int ROW = 10;
    private static final int COL = 10;
    private int MINE_CNT = 10;
    private static final String MINE = " * ";
    private static final String NONE = " 0 ";
    private static final String HIDE = " □ ";
    private String[][] mineArr = null;
    private String[][] mineArrHide = null;
    Scanner sc;
    
    public Mine(String player) {
    	message = "지뢰 찾기 게임을 실행합니다.\n";
    	slowPrint(message,40);
    	playerName = player;
    	gameState = true;
    	sc = new Scanner(System.in);
    	mineArr = new String[ROW][COL];
    	mineArrHide = new String[ROW][COL];
    }
    /*
    private void setInit() {
    	for(int i=0; i<ROW; i++) {
    		for(int j=0; j<COL; j++) {
    			mineArr[i][j] = NONE;
    			mineArrHide[i][j] = HIDE;
    		}
    	}
    }*/
    
    private void setMine(int mineCnt) {
    	Random rand = new Random();
    	
    	while(mineCnt-- > 0) {
    		int row = rand.nextInt(ROW);
    		int col = rand.nextInt(COL);
    		
    		if(mineArr[row][col].equals(MINE)) {
    			mineCnt++;
    		}
    		if(mineArr[row][col].equals(NONE)) {
    			mineArr[row][col] = MINE;
    		}
    	}
    }
    
    private boolean isExistMine(int row, int col) {
    	if(row<0 || row>=ROW || col<0 || col>=COL) {
    		return false;
    	}
    	return mineArr[row][col].equals(MINE);
    }
    
    private int getMineNumber(int row, int col) {
    	int mineCnt = 0;
    	if(isExistMine(row-1, col-1))mineCnt++;
        if(isExistMine(row-1, col))mineCnt++;
        if(isExistMine(row-1, col+1))mineCnt++;
        if(isExistMine(row, col-1))mineCnt++;
        if(isExistMine(row, col+1))mineCnt++;
        if(isExistMine(row+1, col-1))mineCnt++;
        if(isExistMine(row+1, col))mineCnt++;
        if(isExistMine(row+1, col+1))mineCnt++;
        
        return mineCnt;
    }
    
    private void setNumber(int row, int col) {
    	if(mineArr[row][col].equals(NONE) && getMineNumber(row,col)!=0) {
    		mineArr[row][col] = " " + getMineNumber(row,col) + " ";
    	}
    }
    /*
    private void printMine() {
    	for(int i=0; i<ROW; i++) {
    		for(int j=0; j<COL; j++) {
    			setNumber(i,j);
    			System.out.print(mineArrHide[i][j]);
    		}
    		System.out.println();
    	}
    }*/
    
    private void openZeroSquare(int x, int y) {
		if(((x-1)>=0 && (x-1)<ROW) && ((y-1)>=0 && (y-1)<COL)) {
			if(mineArr[x-1][y-1].equals(NONE)) {
				mineArrHide[x-1][y-1] = mineArr[x-1][y-1];
			}
		}
        if(((x-1)>=0 && (x-1)<ROW) && (y>=0 && y<COL)) {
        	if(mineArr[x-1][y].equals(NONE)) {
        		mineArrHide[x-1][y] = mineArr[x-1][y];
			}
        }
        if(((x-1)>=0 && (x-1)<ROW) && ((y+1)>=0 && (y+1)<COL)) {
        	if(mineArr[x-1][y+1].equals(NONE)) {
        		mineArrHide[x-1][y+1] = mineArr[x-1][y+1];
        	}
        }
        if((x>=0 && x<ROW) && ((y-1)>=0 && (y-1)<COL)) {
        	if(mineArr[x][y-1].equals(NONE)) {
        		mineArrHide[x][y-1] = mineArr[x][y-1];
        	}
        }
        if((x>=0 && x<ROW) && ((y+1)>=0 && (y+1)<COL)) {
        	if(mineArr[x][y+1].equals(NONE)) {
        		mineArrHide[x][y+1] = mineArr[x][y+1];
        	}
        }
        if(((x+1)>=0 && (x+1)<ROW) && ((y-1)>=0 && (y-1)<COL)) {
        	if(mineArr[x+1][y-1].equals(NONE)) {
        		mineArrHide[x+1][y-1] = mineArr[x+1][y-1];
        	}
        }
        if(((x+1)>=0 && (x+1)<ROW) && (y>=0 && y<COL)) {
        	if(mineArr[x+1][y].equals(NONE)) {
        		mineArrHide[x+1][y] = mineArr[x+1][y];
        	}
        }
        if(((x+1)>=0 && (x+1)<ROW) && ((y+1)>=0 && (y+1)<COL)) {
        	if(mineArr[x+1][y+1].equals(NONE)) {
        		mineArrHide[x+1][y+1] = mineArr[x+1][y+1];
        	}
        }
	}
    
	@Override
	public void startScreen() {
		message = "지뢰찾기 게임은 10x10의 판 위에 AI 민숭실이 숨겨놓은 지뢰를 피해 모든 숫자를 나타나게 하면 성공입니다!!\n"
				+ "각 판은 숫자 혹은 지뢰를 담고 있으며, 각 판에 적힌 숫자는 주변에 있는 지뢰의 개수입니다.\n"
				+ "주위에 지뢰가 없는 판은 0으로 나타나고, 그 판을 오픈하면 주변 8방향에 있는 0의 판이 모두 오픈됩니다. 이를 잘 활용해서 성공해보세요^^\n"
				+ "시작할 때 고르는 난이도에 따라 숨겨놓는 지뢰의 개수가 달라집니다.\n" + "1단계: 지뢰 10개, 2단계: 지뢰 20개, 3단계: 지뢰 30개\n";
		slowPrint(message,40);
	}

	@Override
	public void endScreen() {
		message = "지뢰 찾기 게임이 종료됩니다.\n";
		slowPrint(message,40);
	}

	@Override
	public void run() {
		System.out.println("<<<<<<<<<<   지  뢰  찾  기      >>>>>>>>>>");
		message = "난이도를 선택하세요. 기본 값은 low 단계입니다.(1(low),2(mid),3(high)) >> ";
		slowPrint(message, 40);
		int h = sc.nextInt();
		switch(h) {
		case 1:
			MINE_CNT = 10;
			break;
		case 2:
			MINE_CNT = 20;
			break;
		case 3:
			MINE_CNT = 30;
			break;
		default:
			break;
		}
		
		makePanel();
		setMine(MINE_CNT);
		while(gameState) {
			showPanel();
			
			message = "열고자 하는 x 좌표를 입력하세요(1~10) >> ";
			slowPrint(message,40);
			int x = sc.nextInt();
			message = "열고자 하는 y 좌표를 입력하세요(1~10) >> ";
			slowPrint(message,40);
			int y = sc.nextInt();
			x -=1;
			y -=1;
			while(x<0 || y<0 || x>=10 || y>=10 || !mineArrHide[x][y].equals(" □ ")) {
				message = "다시 입력해주세요.\n" + "열고자 하는 x 좌표를 입력하세요(1~10) >> ";
				slowPrint(message,40);
				x = sc.nextInt();
				x -= 1;
				message = "열고자 하는 y 좌표를 입력하세요(1~10) >> ";
				slowPrint(message,40);
				y = sc.nextInt();
				y -= 1;
			}
			//사용자가 오픈한 것 보여주기
			mineArrHide[x][y] = mineArr[x][y];
			
			//0을 찾았을 때 주위 0 함께 열리게 하기
			if(mineArr[x][y].equals(NONE)) {
				openZeroSquare(x,y);
			}
			
			//지뢰 터졌을때 게임 종료
			if(mineArr[x][y].equals(MINE)) {
				message = "!!!!!!지뢰가 터졌습니다!!!!!!\n" + "AI 민숭실의 승리입니다.\n";
				slowPrint(message,40);
				allScore[3] = "지뢰 찾기 게임의 승자: " + "AI 민숭실";
				for(int i=0; i<ROW; i++) {
					for(int j=0; j<COL; j++) {
						mineArrHide[i][j] = mineArr[i][j];
					}
				}
				showPanel();
				gameState = false;
				break;
			}
			//지뢰 안건드리고 모두 오픈했을 때 게임 종료
			gameState = checkPanel();
		}
		endScreen();
	}

	@Override
	public void makePanel() {
		for(int i=0; i<ROW; i++) {
    		for(int j=0; j<COL; j++) {
    			mineArr[i][j] = NONE;
    			mineArrHide[i][j] = HIDE;
    		}
    	}
	}

	@Override
	public void showPanel() {
		for(int i=0; i<ROW; i++) {
    		for(int j=0; j<COL; j++) {
    			setNumber(i,j);
    			System.out.print(mineArrHide[i][j]);
    		}
    		System.out.println();
    	}
	}

	@Override
	public boolean checkPanel() {
		//지뢰 안건드리고 모두 오픈했을 때 게임 종료
		boolean checkFinish = true;
		for(int i=0; i<ROW; i++) {
			for(int j=0; j<COL; j++) {
				if(mineArr[i][j].equals(MINE))
					continue;
				else if(!mineArr[i][j].equals(mineArrHide[i][j])) {
					checkFinish = false;
					break;
				}
			}
			if(checkFinish==false) break;
		}
		if(checkFinish) {
			message = "!!!!!지뢰 찾기를 성공하였습니다!!!!!\n" + playerName + "님의 승리입니다.\n";
			slowPrint(message,40);
			allScore[3] = "지뢰 찾기 게임의 승자: " + playerName;
			showPanel();
			return false;
		}
		return true;
	}
	
}
