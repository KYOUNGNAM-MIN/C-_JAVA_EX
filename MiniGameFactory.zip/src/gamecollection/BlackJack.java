package gamecollection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

// map 사용으로 컬렉션클래스 사용. Key(카드 이름)와 Value(그 카드의 값) 저장

public class BlackJack extends GameMain{
	Scanner sc;
	private Map<String, Integer> card;
	private String[] aiCardKey = new String[2];
	private int[] aiCardValue = new int[2];
	private String[] playerCardKey = new String[2];
	private int[] playerCardValue = new int[2];
	private static int aiMoney = 10000;
	private static int playerMoney = 10000;
	private static int betSum = 0;
	
	public BlackJack(String player) {
		message = "블랙 잭 게임을 실행합니다.\n";
		slowPrint(message, 40);
		gameState = true;
		sc = new Scanner(System.in);
		playerName = player;
	}
	
	@Override
	public void startScreen() {
		message = playerName + "님 안녕하세요. 블랙 잭 게임에 오신 것을 환영합니다.\n" + "블랙 잭 게임은 AI 가이드 민숭실과 대결하게 됩니다.\n" 
				+ "블랙 잭 게임은 딜러가 나눠주는 2장의 카드의 합이 21에 가까운 사람이 이기는 게임입니다.\n" + "게임을 시작할 때 각각 10000원이 주어지고, 베팅을 하고 승자가 베팅한 금액을 가져가는 방식으로 상대의 돈을 0원으로 만들 때 까지 게임을 하게 됩니다.\n"
				+ "그럼 게임을 시작하겠습니다.\n\n";
		slowPrint(message,40);
	}
	@Override
	public void endScreen() {
		if(aiMoney==0) {
			message = "블랙 잭 게임의 승자는 " + playerName + "님의 승리입니다.\n";
			slowPrint(message,40);
			allScore[1] = "블랙 잭 게임의 승자: " + playerName;
		}
		else {
			message = "블랙 잭 게임의 승자는 AI 민숭실의 승리입니다. 쉽지않죠?\n";
			slowPrint(message,40);
			allScore[1] = "블랙 잭 게임의 승자: " + "AI 민숭실";
		}
		gameState = false;
	}
	@Override
	public void run() {
		System.out.println("<<<<<<<<<< BLACK JACK >>>>>>>>>>");
		while(gameState) {
			System.out.println();
			//카드 셔플
			message = "카드를 섞습니다.\n";
			slowPrint(message,40);
			cardShuffle();
			//카드 분배
			message = "카드를 분배합니다.\n";
			slowPrint(message,40);
			cardDraw(aiCardKey, aiCardValue);
			cardDraw(playerCardKey, playerCardValue);
			
			System.out.println("------------------------------");
			System.out.println(playerName + "님의 첫 번째 카드: " + playerCardKey[0]);
			System.out.println(playerName + "님의 두 번째 카드: " + playerCardKey[1]);
			System.out.println("------------------------------");
			
			//베팅 시작
			cardBet();
			
			//게임 종료
			if((aiMoney == 0 || playerMoney == 0) && (betSum ==0)) {
				endScreen();
			}
		}
	}
	private void cardBet() {
		message = "베팅을 시작합니다. 최소 베팅금액은 1000원입니다.\n";
		slowPrint(message,40);
		System.out.println("AI 현재 금액: " + aiMoney);
		System.out.println(playerName + "님 현재 금액: " + playerMoney);
		
		int aiCardSum = aiCardValue[0] + aiCardValue[1];
		int playerCardSum = playerCardValue[0] + playerCardValue[1];
		//AI 베팅
		Random rand = new Random();
		int min, max;
		//AI가 이길 경우
		if(aiCardSum > playerCardSum) {
			if(aiMoney<1000) {
				System.out.println("AI의 보유 금액이 최소 베팅 금액인 1000원 보다 적으므로 자동으로 올인됩니다.");
				min = aiMoney;
				max = aiMoney;
			}
			else {
				min = 1000;
				int tmpMin = aiMoney;
				while(tmpMin>2000) {
					min = tmpMin;
					tmpMin -= 500;
				}
				max = aiMoney;
			}
			int aiBetMoneyWin = rand.nextInt(max - min + 1) + min;
			System.out.println("AI 민숭실 베팅금액: " + aiBetMoneyWin + "원");
			aiMoney -= aiBetMoneyWin;
			betSum += aiBetMoneyWin;
		}
		//AI가 질 경우
		else {
			if(aiMoney<1000) {
				System.out.println("AI의 보유 금액이 최소 베팅 금액인 1000원 보다 적으므로 자동으로 올인됩니다.");
				min = aiMoney;
				max = aiMoney;
			}
			else {
				min = 1000;
				max = aiMoney;
				int tmpMax = aiMoney;
				while(tmpMax > 6000) {
					max = tmpMax;
					tmpMax -= 500;
				}
			}
			int aiBetMoneyWin = rand.nextInt(max - min + 1) + min;
			System.out.println("AI 민숭실 베팅금액: " + aiBetMoneyWin + "원");
			aiMoney -= aiBetMoneyWin;
			betSum += aiBetMoneyWin;
		}
		//Player 베팅
		if(playerMoney < 1000) {
			System.out.println(playerName + "님의 보유 금액이 최소 베팅 금액인 1000원보다 적으므로 자동으로 올인됩니다.");
			betSum += playerMoney;
			playerMoney = 0;
		}
		else {
			int playerBetMoney;
			System.out.print(playerName + "님의 베팅금액을 입력해주세요 >> ");
			playerBetMoney = sc.nextInt();
			while(playerBetMoney<1000 || playerBetMoney>playerMoney) {
				if(playerBetMoney<1000) {
					System.out.print("베팅금액은 최소 1000원 이상입니다. 다시 입력해주세요. >> ");
					playerBetMoney = sc.nextInt();
				}
				else {
					System.out.print("현재 보유 금액보다 큰 값을 입력할 수 없습니다. 다시 입력해주세요. >> ");
					playerBetMoney = sc.nextInt();
				}
			}
			playerMoney -= playerBetMoney;
			betSum += playerBetMoney;
		}
		
		System.out.println("------------------------------");
		System.out.println("AI 민숭실의 첫 번째 카드: " + aiCardKey[0]);
		System.out.println("AI 민숭실의 두 번째 카드: " + aiCardKey[1]);
		System.out.println("------------------------------");
		
		if(aiCardSum > playerCardSum) {
			message = "AI 민숭실의 승리입니다.\n";
			slowPrint(message,40);
			aiMoney += betSum;
			betSum = 0;
		}
		else if(aiCardSum < playerCardSum) {
			message = playerName + "님의 승리입니다.\n";
			slowPrint(message,40);
			playerMoney += betSum;
			betSum = 0;
		}
		else {
			message = "무승부입니다. 베팅금액 " + betSum + "원은 다음 게임으로 넘어갑니다.\n";
			slowPrint(message,40);
		}
	}
	private void cardShuffle() {
		// 카드 생성
		card = new HashMap<String, Integer>();
		card.put("A(1)", 1);
		card.put("2(2)", 2);
		card.put("3(3)", 3);
		card.put("4(4)", 4);
		card.put("5(5)", 5);
		card.put("6(6)", 6);
		card.put("7(7)", 7);
		card.put("8(8)", 8);
		card.put("9(9)", 9);
		card.put("k(10)", 10);
		card.put("Q(10)", 10);
		card.put("j(10)", 10);
		card.put("A(11)", 11);
	}
	private void cardDraw(String[] ck, int[] cv) {
		// 카드 분배
		List<Integer> valuesList = new ArrayList<Integer>(card.values());
		List<String> keysList = new ArrayList<String>(card.keySet());
		int randomIndex = new Random().nextInt(valuesList.size());
		Integer randomValue = valuesList.get(randomIndex);
		String randomKey = keysList.get(randomIndex);
		ck[0] = randomKey;
		cv[0] = randomValue;
		valuesList.remove(randomIndex);
		keysList.remove(randomIndex);
		card.remove(randomKey);
		
		randomIndex = new Random().nextInt(valuesList.size());
		randomValue = valuesList.get(randomIndex);
		randomKey = keysList.get(randomIndex);
		ck[1] = randomKey;
		cv[1] = randomValue;
		valuesList.remove(randomIndex);
		keysList.remove(randomIndex);
		card.remove(randomKey);
	}
}
