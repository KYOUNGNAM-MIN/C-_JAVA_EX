package gamecollection;

public interface Panel {
	public abstract void makePanel();
	public abstract void showPanel();
	public abstract boolean checkPanel();
}
