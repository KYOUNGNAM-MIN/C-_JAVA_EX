package gamecollection;

import java.util.Scanner;
import java.util.Random;

public class NumberBaseball extends GameMain{
	Scanner sc;
	Random random;
	private static int strike = 0;
	private static int ball = 0;
	private static int gameTime = 0;
	private int[] aiNum;
	private int[] userNum;
	
	public NumberBaseball(String player) {
		message = "숫자 야구 게임을 실행합니다.\n";
		slowPrint(message, 40);
		gameState = true;
		sc = new Scanner(System.in);
		playerName = player;
		aiNum = new int[3];
		userNum = new int[3];
		random = new Random();
	}
	private void chooseNum() {
	    while(aiNum[0] == 0){
	      aiNum[0] = random.nextInt(10);
	    }
	    while(aiNum[0] == aiNum[1] || aiNum[1] == 0){
	      aiNum[1] = random.nextInt(10);
	    }
	    while(aiNum[0] == aiNum[2] || aiNum[1] == aiNum[2] || aiNum[2] == 0){
	    	aiNum[2] = random.nextInt(10);
	    }
	}
	private void checkNum() {
		for(int i = 0; i< 3; i++){
			for(int j=0; j<3; j++){
				if(aiNum[i] == userNum[j]){
					if(i==j){
						strike+=1;
					}
					else{
						ball+=1;
					}
				}
			}
		}
	       
		if(strike == 0 && ball==0){
	        message = "\nOut!!!\n";
	        slowPrint(message,40);
		}
		else if(strike == 3){
	        message = "\n!!!3 Strike!!!\n" + playerName + "님의 승리입니다.\n";
	        slowPrint(message,40);
	        allScore[2] = "숫자 야구 게임의 승자: " + playerName;
	        gameState = false;
		}
		else{
	        message = "\n" + strike + " 스트라이크" + ball + " 볼\n";
	        slowPrint(message,40);
	        strike=0;
	        ball=0;
		}
	}
	
	@Override
	public void startScreen() {
		message = playerName + "님 안녕하세요. 숫자 야구 게임에 오신 것을 환영합니다.\n" + "숫자 야구 게임은 AI 가이드 민숭실이 정한 3자리의 숫자를 맞추는 게임입니다.\n" 
				+ "민숭실이 정한 3자리의 숫자는 중복이 없이 각각 1~9 사이의 숫자로만 이루어져 있습니다.\n" 
				+ "3자리의 숫자에 대해 예측하는 숫자를 적어주세요.\n" + "숫자와 자리가 일치하는 경우는 Strike, 자리는 틀리고 숫자만 맞는 경우는 Ball, 없는 숫자면 Out 입니다.\n"
				+ "5번의 기회 안에 민숭실이 정한 숫자를 맞추시면 됩니다.\n" + "그럼 게임을 시작하겠습니다.\n\n";
		slowPrint(message,40);
	}

	@Override
	public void endScreen() {
		//게임끝
		message = "숫자 야구 게임이 종료됩니다.\n";
		slowPrint(message,40);
	}

	@Override
	public void run() {
		System.out.println("<<<<<<<<<<   숫  자  야  구      >>>>>>>>>>");
		while(gameState) {
			message = "민숭실이 숫자를 정하고 있습니다.\n";
			slowPrint(message,40);
			chooseNum();
			message = "민숭실이 숫자를 정하였습니다.\n" + playerName + "님이 예측하는 3자리 숫자를 백의 자릿수부터 하나씩 순서대로 입력해주세요!!\n";
			slowPrint(message,40);
			while(strike < 3) {
				gameTime++;
				message = gameTime + "번째 시도입니다.\n";
				slowPrint(message,40);
				for(int i=0; i<userNum.length; i++) {
					message = (i+1) + "번째 수: ";
					slowPrint(message,40);
					userNum[i] = sc.nextInt();
					while(userNum[i] >=10 || userNum[i] <= 0){
			          	message = "1~9 사이의 숫자로 입력하세요.\n" + (i+1) + "번째 수: ";
			          	slowPrint(message,40);
			          	userNum[i] = sc.nextInt();
					}
				}
				checkNum();
				if(!gameState) {
					break;
				}
				if(gameTime==5) {
					message = "\n!!!5번의 시도를 다했음에도 못맞췄으므로 AI 민숭실의 승리입니다!!!\n";
					slowPrint(message,40);
					allScore[2] = "숫자 야구 게임의 승자: " + "AI 민숭실";
					gameState = false;
					break;
				}
			}
		}
		endScreen();
	}
}
